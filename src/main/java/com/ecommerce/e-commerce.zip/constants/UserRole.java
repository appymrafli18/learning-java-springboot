package com.ecommerce.constants;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum UserRole {

    ADMIN, USER;
}
