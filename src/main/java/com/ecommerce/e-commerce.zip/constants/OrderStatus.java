package com.ecommerce.constants;

public enum OrderStatus {

  Pending, Success, Cancelled

}
