package com.ecommerce.exceptions;

public class DuplicateCategoryException extends RuntimeException {
  public DuplicateCategoryException(String message) {
    super(message);
  }
}
