package com.ecommerce.services;

import com.ecommerce.DTOs.requests.ProductPatchRequest;
import com.ecommerce.DTOs.requests.ProductRequest;
import com.ecommerce.exceptions.NotFoundException;
import com.ecommerce.entity.Category;
import com.ecommerce.entity.Product;
import com.ecommerce.repositories.ProductRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class ProductService {

  private final ProductRepository productRepository;
  private final CategoryService categoryService;

  public List<Product> findAll() {
    return productRepository.findAll();
  }

  public Product create(ProductRequest request) {

    Category categorySearch = categoryService.findById(request.getCategoryId());

    Product product = Product.builder()
            .name(request.getName())
            .price(request.getPrice())
            .stock(request.getStock())
            .image(request.getImage().getOriginalFilename())
            .category(categorySearch)
            .build();

    return productRepository.save(product);
  }

  public Product update(Long id, ProductPatchRequest request) {
    Product product = this.findById(id);

    if (request.getName() != null) product.setName(request.getName());
    if (request.getPrice() != null) product.setPrice(request.getPrice());
    if (request.getStock() != null) product.setStock(request.getStock());

    return productRepository.save(product);
  }

  public Product findById(Long id) {
    return productRepository.findById(id).orElseThrow(() -> new NotFoundException("Product not found with id " + id));
  }

  public void delete(Long id) {
    try {
      productRepository.deleteById(id);
    } catch (EmptyResultDataAccessException ex) {
      throw new NotFoundException("Product not found with id " + id);
    }
  }

}
