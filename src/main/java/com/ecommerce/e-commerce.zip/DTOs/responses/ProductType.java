package com.ecommerce.DTOs.responses;

public record ProductType(Long id, String name, Long price, int stock) {
}
